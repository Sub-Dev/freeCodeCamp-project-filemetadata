# Exercise Tracker Microservice

This is the boilerplate code for the Exercise Tracker Microservice project. Instructions for building your project can be found <a href="https://www.freecodecamp.org/learn/back-end-development-and-apis/back-end-development-and-apis-projects/exercise-tracker">here</a>.
